package com.saveetha.kanchi_wave_hub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanchiWaveHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanchiWaveHubApplication.class, args);
	}

}
