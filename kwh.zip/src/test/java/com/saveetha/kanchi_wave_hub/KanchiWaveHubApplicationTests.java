package com.saveetha.kanchi_wave_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanchiWaveHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
